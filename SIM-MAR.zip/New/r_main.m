function r_main(filename, dir1, dir2, d1, d2)
%%参数表
num_seeds = 200;
compactness = 40;
foreground = 255;
background = 0;
Vate1 = 0.2;%变化率
Vate2 = 0.5;%占有率
%%初始化数据
Image = imread(strcat(filename, dir1, 'in000001.jpg'));
Len = length(dir(strcat(filename, dir1, '*.jpg')));
[Height, Width, ~] = size(Image);
map = zeros(Height, Width);
active_map = zeros(Height, Width);
%%模型初始化
tic
labels_arry = map_init(Image, num_seeds, compactness);
toc
fprintf('Map is initialized\n');

%%分类
for suq = 1 : Len  
    im = imread(strcat(filename, dir1, 'in', num2str(suq,'%06d'), '.jpg'));
    [labels]=SLIC(num_seeds, compactness, im);
    attention_labels = labels(vertcat(labels_arry{3, :}));%所有注意力点标签
    min_value = min(min(labels));
    max_value = max(max(labels));
    R = im(:, :, 1);
    G = im(:, :, 2);
    B = im(:, :, 3);
    
    frame_start_time = tic;
    for q = min_value : max_value
        att_pis = find(attention_labels == q);%q标签的注意力点labels_arry位置
        [att_num, ~] = size(att_pis);
        if att_num < 1
            map(att_arry_pis) = background;
        elseif att_num == 1
            att_arry_pis = labels_arry{1, att_pis};
            att_arry_labels = labels(att_arry_pis);
            Now_SLIC_pis = find(labels == q);
            [x1, ~] = size(Now_SLIC_pis);%当前超像素标签个数
            [x2, ~] = size(find(att_arry_labels == q));%注意点标签组未离群个数
            [x3, ~] = size(att_arry_pis);%注意点标签组个数
            
            Th1 = abs(x3 - x1)/x3;%体积变化率
            Th2 = x2/x1;%故土占有率
            if Th1 > Vate1 || Th2 < Vate2
                Class_1 = zeros(x3, 3);
                Class_1(:,1) = R(att_arry_pis);
                Class_1(:,2) = G(att_arry_pis);
                Class_1(:,3) = B(att_arry_pis);
                att_pixel_1 = labels_arry{2, att_pis};
                Class = [Class_1; att_pixel_1];
                dist = squareform(pdist(Class));
                Dist = dist(1:x3, x3+1);
                ex = Dist > labels_arry{4, att_pis};
                map(att_arry_pis(ex)) = foreground;
            else
                map(att_arry_pis) = background;
            end
        else
           map(att_arry_pis) = background; 
        end

    end
    fprintf('%s %s frame %d took %f seconds\n', d1, d2, suq, toc(frame_start_time));
    imwrite(map,strcat(filename, dir2, 'bin', num2str(suq,'%06d'), '.png'));   
end

end