clear
clc

filename = 'H:\Dynamic Detection Dataset\dataset2014\';
for D1 = 1 : 11
    t = tic;
%     D1 = 2;
     [d1, Dr2] = path_d1(D1);
    for D2 = 1 : Dr2
%     for D2 = 1 : 1
        d2 = path_d2(D1, D2);
        dir1 = strcat('dataset\',d1,'\',d2,'\input\');
        dir2 = strcat('New\',d1,'\',d2,'\');
        r_main2(filename, dir1, dir2, d1, d2);
        
        fprintf('frame all_suq took %f seconds\n', toc(t));
    end
end