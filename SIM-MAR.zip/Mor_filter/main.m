clear
clc

filename = 'H:\Dynamic Detection Dataset\dataset2014\';
% for D1 = 1 : 11
    t = tic;
    D1 = 4;
     [d1 , Dr2] = path_d1(D1);
    for D2 = 1 : Dr2
        d2 = path_d2(D1,D2);
        dir1 = strcat('SIM2IR\',d1,'\',d2,'\');
        dir2 = strcat('Filter\',d1,'\',d2,'\');
        Mor_filter(filename,dir1,dir2,d1,d2);
        
        fprintf('frame all_suq took %f seconds\n',toc(t));
    end
% end