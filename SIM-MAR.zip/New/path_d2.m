function d2 = path_d2(D1, D2)
if D1 == 1
    if D2 ==1
        d2 = 'blizzard';
    end
    if D2 == 2
       d2 = 'skating';
    end
    if D2 == 3
       d2 = 'snowFall';
    end
    if D2 == 4
       d2 = 'wetSnow';
    end
end

if D1 == 2
    if D2 ==1
        d2 = 'highway';
    end
    if D2 == 2
       d2 = 'office';
    end
    if D2 == 3
       d2 = 'pedestrians';
    end
    if D2 == 4
       d2 = 'PETS2006';
    end
end

if D1 == 3
    if D2 ==1
        d2 = 'badminton';
    end
    if D2 == 2
       d2 = 'boulevard';
    end
    if D2 == 3
       d2 = 'sidewalk';
    end
    if D2 == 4
       d2 = 'traffic';
    end
end

if D1 == 4
    if D2 ==1
        d2 = 'boats';
    end
    if D2 == 2
       d2 = 'canoe';
    end
    if D2 == 3
       d2 = 'fall';
    end
    if D2 == 4
       d2 = 'fountain01';
    end
    if D2 == 5
       d2 = 'fountain02';
    end
    if D2 == 6
       d2 = 'overpass';
    end
end

if D1 == 5
    if D2 ==1
        d2 = 'abandonedBox';
    end
    if D2 == 2
       d2 = 'parking';
    end
    if D2 == 3
       d2 = 'sofa';
    end
    if D2 == 4
       d2 = 'streetLight';
    end
    if D2 == 5
       d2 = 'tramstop';
    end
    if D2 == 6
       d2 = 'winterDriveway';
    end
end

if D1 == 6
    if D2 ==1
        d2 = 'port_0_17fps';
    end
    if D2 == 2
       d2 = 'tramCrossroad_1fps';
    end
    if D2 == 3
       d2 = 'tunnelExit_0_35fps';
    end
    if D2 == 4
       d2 = 'turnpike_0_5fps';
    end
end

if D1 == 7
    if D2 ==1
        d2 = 'bridgeEntry';
    end
    if D2 == 2
       d2 = 'busyBoulvard';
    end
    if D2 == 3
       d2 = 'fluidHighway';
    end
    if D2 == 4
       d2 = 'streetCornerAtNight';
    end
    if D2 == 5
       d2 = 'tramStation';
    end
    if D2 == 6
       d2 = 'winterStreet';
    end
end

if D1 == 8
    if D2 ==1
        d2 = 'continuousPan';
    end
    if D2 == 2
       d2 = 'intermittentPan';
    end
    if D2 == 3
       d2 = 'twoPositionPTZCam';
    end
    if D2 == 4
       d2 = 'zoomInZoomOut';
    end
end

if D1 == 9
    if D2 ==1
        d2 = 'backdoor';
    end
    if D2 == 2
       d2 = 'bungalows';
    end
    if D2 == 3
       d2 = 'busStation';
    end
    if D2 == 4
       d2 = 'copyMachine';
    end
    if D2 == 5
       d2 = 'cubicle';
    end
    if D2 == 6
       d2 = 'peopleInShade';
    end
end

if D1 == 10
    if D2 ==1
        d2 = 'corridor';
    end
    if D2 == 2
       d2 = 'diningRoom';
    end
    if D2 == 3
       d2 = 'lakeSide';
    end
    if D2 == 4
       d2 = 'library';
    end
    if D2 == 5
       d2 = 'park';
    end
end

if D1 == 11
    if D2 ==1
        d2 = 'turbulence0';
    end
    if D2 == 2
       d2 = 'turbulence1';
    end
    if D2 == 3
       d2 = 'turbulence2';
    end
    if D2 == 4
       d2 = 'turbulence3';
    end
end
end