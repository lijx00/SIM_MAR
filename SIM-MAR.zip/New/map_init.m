function [labels_arry, Num] = map_init(Image, num_seeds, compactness)
% 1是所有标签位置
% 2是注意点值
% 3是注意点位置
% 4是所有标签判断半径
% 5是活跃度标签
[labels]=SLIC(num_seeds, compactness, Image);
min_value = min(min(labels));
max_value = max(max(labels));
Num = max_value - min_value + 1;
labels_arry = cell(5, Num);

count = 1;
for q = min_value : max_value
    labels_arry{1, count} = find(labels == q);
    [m, ~] = size(labels_arry{1, count});
    class = zeros(m, 3);
    
    R = Image(:, :, 1);
    G = Image(:, :, 2);
    B = Image(:, :, 3);
    class(:, 1) = R(labels_arry{1, count});
    class(:, 2) = G(labels_arry{1, count});
    class(:, 3) = B(labels_arry{1, count});
    
    dist = squareform(pdist(class));
    [~, pis] = min(sum(dist));
    arry = labels_arry{1, count};
    labels_arry{2, count} = class(pis, :);
    labels_arry{3, count} = arry(pis, 1);
    labels_arry{4, count} = max(dist(:,pis));
    labels_arry{5, count} = 0;
    count = count + 1;
    fprintf('Class %d is initialized\n', q);
end

end