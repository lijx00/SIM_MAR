function run_main(filename,dir1,dir2,d1,d2)


Len = length(dir(strcat(filename,dir1,'*.png')));

for suq = 1 : Len
    frame_start_time = tic;
    im = imread(strcat(filename,dir1,'bin',num2str(suq,'%06d'),'.png'));
    imfilter = medfilt2(im);
    fprintf('%s %s frame %d took %f seconds\n', d1 ,d2,suq, toc(frame_start_time));

    imwrite(imfilter,strcat(filename,dir2,'bin',num2str(suq,'%06d'),'.png'));
end

end