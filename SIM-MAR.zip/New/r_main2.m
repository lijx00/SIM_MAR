function r_main2(filename, dir1, dir2, d1, d2)
%%参数表
num_seeds = 200;
compactness = 40;
foreground = 255;
background = 0;
Vate1 = 0.5;%变化率
Vate2 = 0.5;%占有率
%%初始化数据
Image = imread(strcat(filename, dir1, 'in000001.jpg'));
Len = length(dir(strcat(filename, dir1, '*.jpg')));
[Height, Width, ~] = size(Image);
map = zeros(Height, Width);
%%模型初始化
tic
[labels_arry, Num] = map_init(Image, num_seeds, compactness);
toc
fprintf('Map is initialized\n');

%%分类
for suq = 1 : Len  
    im = imread(strcat(filename, dir1, 'in', num2str(suq,'%06d'), '.jpg'));
    [labels]=SLIC(num_seeds, compactness, im);
    R = im(:, :, 1);
    G = im(:, :, 2);
    B = im(:, :, 3);
    
    frame_start_time = tic;
    for q = 1 : Num
        att_value = labels_arry{2, q};%注意点值
        att_pis  = labels_arry{3, q};%注意点位置
        att_arry  = labels_arry{1, q};%注意点管辖区
        r = labels_arry{4, q};%判定半径
        
        att_labels = labels(att_pis);
        att_arry_labels = labels(att_arry);
        x = find(att_arry_labels == att_labels);
        [Now_territory, ~] = size(x);
        [att_territory, ~] = size(att_arry);
        Th = Now_territory/att_territory;
        att_now_value(1,1) = R(att_pis);
        att_now_value(1,2) = G(att_pis);
        att_now_value(1,3) = B(att_pis);
%         RR = sqrt(sum((att_now_value - att_value).^2));
        if Th < Vate1 || labels_arry{5, q} ~= 0
            Class = zeros(att_territory, 3);
            Class(:, 1) = R(att_arry);
            Class(:, 2) = G(att_arry);
            Class(:, 3) = B(att_arry);
            Class = [Class; att_value];
            dist = squareform(pdist(Class));
            Dist = dist(1:att_territory, att_territory+1);
            ex = Dist > r;
            ax = Dist <= r;
            map(att_arry(ex)) = foreground;
            map(att_arry(ax)) = background;
            [V,~] = size(ex);
            Va = V/att_territory;
            if Va > Vate2
                labels_arry{5, q} = 1;
            else
                labels_arry{5, q} = 0;
            end
        else
            map(att_arry) = background;
        end
    end
    fprintf('%s %s frame %d took %f seconds\n', d1, d2, suq, toc(frame_start_time));
    imwrite(map,strcat(filename, dir2, 'bin', num2str(suq,'%06d'), '.png'));   
end

end