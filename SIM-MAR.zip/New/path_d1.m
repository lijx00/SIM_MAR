function  [d1, Dr2] = path_d1(D1)
if D1 == 1
    d1 = 'badWeather';
    Dr2 = 4;
end

if D1 == 2
    d1 = 'baseline';
    Dr2 = 4;
end

if D1 == 3
    d1 = 'cameraJitter';
    Dr2 = 4;
end

if D1 == 4
    d1 = 'dynamicBackground';
    Dr2 = 6;
end

if D1 == 5
    d1 = 'intermittentObjectMotion';
    Dr2 = 6;
end

if D1 == 6
    d1 = 'lowFramerate';
    Dr2 = 4;
end

if D1 == 7
    d1 = 'nightVideos';
    Dr2 = 6;
end

if D1 == 8
    d1 = 'PTZ';
    Dr2 = 4;
end

if D1 == 9
    d1 = 'shadow';
    Dr2 = 6;
end

if D1 == 10
    d1 = 'thermal';
    Dr2 = 5;
end

if D1 == 11
    d1 = 'turbulence';
    Dr2 = 4;
end
end