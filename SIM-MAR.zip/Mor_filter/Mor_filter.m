function Mor_filter(filename,dir1,dir2,d1,d2)

Len = length(dir(strcat(filename,dir1,'*.png')));

for i = 1:Len
    frame_start_time = tic;
    im = imread(strcat(filename,dir1,'bin',num2str(i,'%06d'),'.png'));   
    i1 = bwmorph(im,'remove'); 
    i2 = double(im)-255*double(i1);
    i3 = bwmorph(i2,'open');
    i4 = bwmorph(i3,'close');
    segMap = uint8(255*double(i4));
    fprintf('%s %s frame %d took %f seconds\n', d1 ,d2,i, toc(frame_start_time));
   %if (~isempty(find(ground_truth_frames == i)))
    imwrite(segMap(:,:),strcat(filename,dir2,'bin',num2str(i,'%06d'),'.png'));
   %end
end
end
